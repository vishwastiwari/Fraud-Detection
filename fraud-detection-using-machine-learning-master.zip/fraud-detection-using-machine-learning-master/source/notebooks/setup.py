from distutils.core import setup


setup(
    name='package',
    version='1.0',
    description="A package to organize the solution's code.",
    package_dir={'': 'src'},
    packages=['package'],
)
